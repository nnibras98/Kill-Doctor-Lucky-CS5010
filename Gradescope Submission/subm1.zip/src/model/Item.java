package model;

public class Item {

  private int roomIndex;
  private int damage;
  private String name;

  public Item(int roomIndex, int damage, String name) {

    this.roomIndex = roomIndex;
    this.damage = damage;
    this.name = name;
  }

  public int getRoomIndex() {
    return roomIndex;
  }

  public int getDamage() {
    return damage;
  }

  public String getName() {
    return name;
  }
}
