package model;

import java.util.ArrayList;
import java.util.List;

public class Room {
  private int upperLeftRow;
  private int upperLeftColumn;
  private int lowerRightRow;
  private int lowerRightColumn;
  private int index;
  private String name;

  public Room(int upperLeftRow, int upperLeftColumn, int lowerRightRow, int lowerRightColumn,
      String name, int index) {

    this.upperLeftRow = upperLeftRow;
    this.upperLeftColumn = upperLeftColumn;
    this.lowerRightRow = lowerRightRow;
    this.lowerRightColumn = lowerRightColumn;
    this.name = name;
    this.index = index;
  }

  public int getUpperLeftRow() {
    return upperLeftRow;
  }

  public int getUpperLeftColumn() {
    return upperLeftColumn;
  }

  public int getLowerRightRow() {
    return lowerRightRow;
  }

  public int getLowerRightColumn() {
    return lowerRightColumn;
  }

  public String getName() {
    return name;
  }

  public int getIndex() {
    return index;
  }

  // Get a list of all neighboring rooms
  public List<Room> getNeighbors(List<Room> allRooms) {
    List<Room> neighbors = new ArrayList<>();

    for (Room otherRoom : allRooms) {
      if (areNeighbors(otherRoom)) {
        neighbors.add(otherRoom);
      }
    }

    return neighbors;
  }

  // Check if two rooms are neighbors
  //There is a bug which I am trying to fix, not sure if it will make it to the production tonight
  public boolean areNeighbors(Room otherRoom) {
    // Check if the rooms share a common "wall"
    boolean verticallyAdjacent = ((this.lowerRightRow == otherRoom.upperLeftRow - 1)
        || (this.upperLeftRow == otherRoom.lowerRightRow + 1));
    boolean horizontallyAdjacent = ((this.lowerRightColumn == otherRoom.upperLeftColumn - 1)
        || (this.upperLeftColumn == otherRoom.lowerRightColumn + 1));

    return (verticallyAdjacent || horizontallyAdjacent);
  }

  public void displayRoomInfo(List<Room> allRooms, List<Item> allItems) {
    System.out.println("Room Name: " + this.getName());

    // Display items in the room
    System.out.println("Items in the Room:");
    for (Item item : getItemsInRoom(allItems)) {
      System.out.println("- " + item.getName());
    }

    // Display spaces that can be seen from this room
    System.out.println("Spaces That Can Be Seen:");
    List<Room> visibleRooms = getVisibleRooms(allRooms);
    for (Room visibleRoom : visibleRooms) {
      System.out.println("- " + visibleRoom.getName());
    }
  }

  public List<Item> getItemsInRoom(List<Item> allItems) {
    List<Item> itemsInRoom = new ArrayList<>();
    for (Item item : allItems) {
      if (item.getRoomIndex() == getIndex()) {
        itemsInRoom.add(item);
      }
    }
    return itemsInRoom;
  }

  public List<Room> getVisibleRooms(List<Room> allRooms) {
    List<Room> visibleRooms = new ArrayList<>();
    for (Room room : allRooms) {
      if (room != this) {

        if (areNeighbors(room)) {
          visibleRooms.add(room);
        }
      }
    }
    return visibleRooms;
  }

}
