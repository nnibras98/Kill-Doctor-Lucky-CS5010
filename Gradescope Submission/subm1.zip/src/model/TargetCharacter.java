package model;

public class TargetCharacter {
  private int health;
  private String name;
  private int characterPositionIndex = 0;

  public TargetCharacter(int health, String name) {
    this.health = health;
    this.name = name;
  }

  public int getHealth() {
    return health;
  }

  public void setHealth(int health) {
    this.health = health;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public int getCharacterPositionIndex() {
    return characterPositionIndex;
  }

  public void moveCharacterForward() {

    if (characterPositionIndex > 21) {
      throw new IllegalArgumentException("Invalid Movement");
    }

    characterPositionIndex += 1;
  }

  public void moveCharacterBackward() {

    if (characterPositionIndex < 0) {
      throw new IllegalArgumentException("Invalid Movement");
    }
    characterPositionIndex -= 1;

  }
}
